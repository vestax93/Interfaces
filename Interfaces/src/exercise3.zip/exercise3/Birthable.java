package exercise3;

public interface Birthable {
    String getBirthDate();
}
