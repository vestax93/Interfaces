package exercise3;

public interface Person {
    String getName();
    int getAge();
}
