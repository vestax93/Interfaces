package exercise3;

public interface Identifiable {
    String getId();
}
