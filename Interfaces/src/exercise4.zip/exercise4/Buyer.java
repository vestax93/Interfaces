package exercise4;

public interface Buyer {
    void buyFood();
    int getFood();

}
