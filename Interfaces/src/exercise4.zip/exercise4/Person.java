package exercise4;

public interface Person {
    String getName();
    int getAge();
}
