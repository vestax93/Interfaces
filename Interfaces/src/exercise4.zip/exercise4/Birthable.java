package exercise4;

public interface Birthable {
    String getBirthDate();
}
