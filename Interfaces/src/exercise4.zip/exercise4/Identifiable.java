package exercise4;

public interface Identifiable {
    String getId();
}
