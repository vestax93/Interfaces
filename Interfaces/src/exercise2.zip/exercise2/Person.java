package exercise2;

public interface Person {
    String getName();
    int getAge();
}
