package exercise2;

public interface Birthable {
    String getBirthDate();
}
