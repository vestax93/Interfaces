package exercise2;

public interface Identifiable {
    String getId();
}
