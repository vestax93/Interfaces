package exercise1;

public interface Person {
    String getName();
    int getAge();
}
