package exercise5;

public interface Browsable {
    String browse();
}
