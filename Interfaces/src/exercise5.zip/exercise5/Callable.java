package exercise5;

public interface Callable {
    String call();}
