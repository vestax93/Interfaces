package exercise7;

public interface MyList extends AddRemovable {

    int getUsed();
}
