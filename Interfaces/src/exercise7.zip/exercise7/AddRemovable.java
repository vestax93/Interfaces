package exercise7;

public interface AddRemovable extends Addable{

    String remove();
}
